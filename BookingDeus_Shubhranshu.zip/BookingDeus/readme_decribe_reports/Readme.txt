Hi Team,

This project is created using POM pattern with page factory using testNg frameowrk we have used this framework because it is easy to maintain whenever we will have new functionality that time we just need to create the POM using Page Factory and add the new annotations for the test cases.

We have very less function so within one class we have created two test cases, if we want to automate this website end to end so we can easily do using this framework.

Validation what we have done in this project:
1) We have used selenium here.
2) We are redirecting ourself to Booking.com and entering the city as Porto.
3) we are clicking Check-in: 1st of the next month and Check-out: 7th of the next month;
4) Clicking on the Search button.
5) Printng the total number of properties found on the console
6) Verifying the CheckIn and CheckOut Date.
7) Printing the names of the properties found on the first page


Highlights of this project.
1) Reusable component is available e.g Explicit wait.
2) Reporting is available, whenever the test case will be pass or fail that time report will going to generate, for fail we will have the error message also.
3) Java OOPS concept is implemented in this project e.g. Inheritance,Interface,encapsulation etc.
4) We can run this project on different browser we just need to change the data in global properties file.
5) We can run the test case through Booking TestCase package and testng.xml file more details with Screenshot available in the "Booking.com_Reports" word file 


Note: For more details and end to end execution result we can refer "Booking.com_Reports" word file 



Regards
Shubhranshu